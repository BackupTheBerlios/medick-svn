<?php

/** This file is part of todo application, 
 * a medick framwork demo */

class Todo extends ActiveRecordBase {

    public static function find_done() {
        return self::find('all', array('condition'=>'done=1'));
    }

    public static function find_not_done() {
        return self::find('all', array('condition'=>'done=0'));
    }
}
