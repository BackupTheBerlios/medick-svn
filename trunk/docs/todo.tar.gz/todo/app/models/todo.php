<?php

class Todo extends ActiveRecordBase {
    
}
