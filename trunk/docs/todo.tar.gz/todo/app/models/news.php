<?php

class News extends ActiveRecordBase {
    
}
