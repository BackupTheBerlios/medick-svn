<?php

// todo helper

function doSmthing() {
    return 'Bar';
}

?>
