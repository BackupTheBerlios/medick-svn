<?php

/** This file is part of 
 * the sample application for medick PHP framework */

class TodoController extends ApplicationController {

    /** our model */
    protected $model = array('todo');

    /** List all todo items */
    public function all() {
        $this->template->done = Todo::find_done();
        // $this->template->done = Todo::find();
        $this->template->not_done = Todo::find_not_done();
    }
    
    /** removes an item from the todo list */
    public function delete() {
        $item = new Todo(array('id'=>$this->params['id']));
        try {
            $item->destroy();
            $this->redirect_to('all');
        } catch (SQLException $sqlEx) {
            $this->logger->warn('SQLException Caugth!' . $sqlEx->getMessage());
            $this->render_text('Cannot Delete!');
        }
    }

    /** It adds a new item (form processor) */
    public function add() {
        $item = new Todo();
        $item->description=$this->params['description'];
        try {
            $item->save();
            $this->redirect_to('all');
        } catch (SQLException $sqlEx) {
            $this->logger->warn('SQLException caught!' . $sqlEx->getMessage());
            $this>render_text('Cannot Save!');
        }
    }

    /** toggle done flag */
    public function toggle_check() {
        $item = Todo::find($this->params['id']);
        $item->done = $item->done ? 0 : 1;
        try {
            $item->save();
            $this->redirect_to('all');
        } catch (SQLException $sqlEx) {
            $this->logger->warn('SQLException caught!' . $sqlEx->getMessage());
            $this->render_text('Cannot toggle');
        }
    }
}
