<?php

class TodoController extends ApplicationController {
    
    protected $model = array('todo');
    
    public function all() {
    	$this->template->items = Todo::find();
    }
    
    public function add() {
    	$this->render_text("Hello World!");
//    	$todo = new Todo();
//    	$todo->description = "A new Todo";
//    	$todo->done = FALSE;
//    	try {
//    		$todo->save();
//    	} catch (Exception $ex) {
//    		echo $ex->getMessage();	
//    	}
    	
    }
    
}
