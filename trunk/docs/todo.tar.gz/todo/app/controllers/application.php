<?php

    class ApplicationController extends ActionControllerBase {

    }

?>
