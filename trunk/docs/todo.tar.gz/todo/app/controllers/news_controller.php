<?php

class NewsController extends ApplicationController {
    
    protected $before_filter = array('length');
    
    protected $model = array('news', 'users');
    
    public function __construct() {
        // $this->model = array('news');
    }

    public function alist() {
        return News::find_all();
    }

    public function all() {
        $this->logger->debug('looks good...');
    }

    public static function stats() {
        echo "Here!";
    }

    
    // public function __destruct() {
    //    echo __METHOD__ . "<br />";
    // }
    
    private function hidden() {
        echo __METHOD__ . "<br />";
    }

    protected function part() {
        echo __METHOD__ . "<br />";
    }
    
    protected function length() {
        $this->logger->debug('Before Filter: ' . __METHOD__ . ' HIT@@@');
    }
}
